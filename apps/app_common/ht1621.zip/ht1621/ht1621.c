

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "ht1621.h"

#define DELAY_10_US 10 * 4
#define DELAY_500_MS 500 * 4

static uint8_t Ht1621Tab[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

/*********************************************************
函数名:SendBit_1621()
返回值:无
功  能:HT1621数据写入函数
Data为数据，cnt为数据位数
//发送指定的位，先发送最高位,用于发送命令与SEG
//dat的高cnt位写入1621，高位在前，如0x80的高三位是100
*********************************************************/
void SendBit_1621(ht1621_t *p_dev, uint8_t data, uint8_t cnt)
{
	uint8_t i;

	for (i = 0; i < cnt; i++)
	{
		p_dev->WR_LOW();

		if ((data & 0x80) == 0) //判断最高位是否为1
		{
			p_dev->DATA_LOW();
		}
		else
		{
			p_dev->DATA_HIGH();
		}

		p_dev->delay_us(DELAY_10_US); //WR引脚变化稍微给点延时，防止速度过快数据传输错误
		p_dev->WR_HIGH();
		p_dev->delay_us(DELAY_10_US);
		data <<= 1; //左移一位，丢弃已经写入的最高位
	}
}

/********************************************************
函数名称：void SendDataBit_1621(uchar data,uchar cnt)
功能描述: HT1621在指定地址写入数据函数
全局变量：无
参数说明：Addr为写入初始地址，Data为写入数据
返回说明：无
说 明：因为HT1621的数据位4位，所以实际写入数据为参数的后4位
//发送指定的位，先发送最低位,用于发送com
//dat的低cnt位写入1621，低位在前
//a5-a4-a3-a2-a1-a0-d0-d1-d2-d3，  a为地址：seg     d 为com
********************************************************/
void SendDataBit_1621(ht1621_t *p_dev, uint8_t data, uint8_t cnt)
{
	uint8_t i;
	for (i = 0; i < cnt; i++)
	{
		if ((data & 0x01) == 0)
		{
			p_dev->DATA_LOW();
		}
		else
		{
			p_dev->DATA_HIGH();
		}

		p_dev->delay_us(DELAY_10_US);
		p_dev->WR_LOW();
		p_dev->delay_us(DELAY_10_US);
		p_dev->WR_HIGH();
		p_dev->delay_us(DELAY_10_US);
		data >>= 1;
	}
}

/********************************************************
函数名称：void SendCmd(uchar Cmd)
功能描述: HT1621命令写入函数
全局变量：无
参数说明：Cmd为写入命令数据
返回说明：无
说 明：写入命令标识位100
********************************************************/
void SendCmd(ht1621_t *p_dev, uint8_t Cmd)
{

	p_dev->CS_LOW();
	p_dev->delay_us(DELAY_10_US);
	SendBit_1621(p_dev, 0x80, 3); // - - 写入命令标志100//写入标志码"100"命令模式
	SendBit_1621(p_dev, Cmd, 9);  // - - 写入命令数据//写入9位数据，其中前8位是命令，最后一位任意。
	p_dev->CS_HIGH();
	p_dev->delay_us(10);
}

/********************************************************
函数名称：void Write_1621(uchar Cmd)
功能描述: HT1621命令写入函数
全局变量：无
参数说明：Cmd为写入命令数据
返回说明：无
//发送命令+地址+数据    地址SEG   com0-com4
********************************************************/
void Write_1621(ht1621_t *p_dev, uint8_t addr, uint8_t data)
{
	p_dev->CS_LOW();
	p_dev->delay_us(DELAY_10_US);
	SendBit_1621(p_dev, 0xA0, 3);	   // - - 写入数据标志101
	SendBit_1621(p_dev, addr << 2, 6); // - - 写入地址数据//写入6位地址，SEG
	SendDataBit_1621(p_dev, data, 4);  //写入DAT低4位，分别对应COM3,COM2,COM1,COM0
	p_dev->CS_HIGH();
	p_dev->delay_us(DELAY_10_US);
}

/********************************************************
函数名称：void WriteAll_1621(uchar Addr,uchar *p,uchar cnt)
功能描述: HT1621连续写入方式函数
全局变量：无
参数说明：Addr为写入初始地址，*p为连续写入数据指针，
cnt为写入数据总数
返回说明：无
说 明：HT1621的数据位4位，此处每次数据为8位，写入数据
总数按8位计算
********************************************************/
void WriteAll_1621(ht1621_t *p_dev, uint8_t Addr, uint8_t *p, uint8_t cnt)
{
	uint8_t i;

	p_dev->CS_LOW();
	SendBit_1621(p_dev, 0xA0, 3);	   // - - 写入数据标志101
	SendBit_1621(p_dev, Addr << 2, 6); // - - 写入地址数据
	for (i = 0; i < cnt; i++)
	{
		SendDataBit_1621(p_dev, *p, 8); // - - 写入数据
		p++;
	}
	p_dev->CS_HIGH();
	p_dev->delay_us(DELAY_10_US);
}

/********************************************************
函数名称：void Ht1621_Init(void)
功能描述: HT1621初始化
全局变量：无
参数说明：无
返回说明：无
版 本：1.0
说 明：初始化后，液晶屏所有字段均显示
********************************************************/
void HT1621_Init(ht1621_t *p_dev)
{
	p_dev->gpio_config();

	p_dev->CS_HIGH();
	p_dev->WR_HIGH();
	p_dev->DATA_HIGH();
	p_dev->delay_ms(DELAY_500_MS); // - - 延时使LCD工作电压稳定

	SendCmd(p_dev, 0x52);
	SendCmd(p_dev, 0X30); // - - 使用内部振荡器 0X30
	SendCmd(p_dev, 0X00); // - - 关振系统荡器和LCD偏压发生器 0X00
	SendCmd(p_dev, 0X0A); // - - 禁止看门狗  0X0A
	SendCmd(p_dev, 0X02); // - - 打开系统振荡器 0X02
	SendCmd(p_dev, 0X06); // - - 打开LCD偏压 0X06

	SendCmd(p_dev, BIAS1_3_4COM); //设定1/3偏压，4个COM  0X29
								  //    SendCmd(RC256); // - - 使用内部振荡器
								  //    SendCmd(SYSDIS); // - - 关振系统荡器和LCD偏压发生器
								  //    SendCmd(WDTDIS); // - - 禁止看门狗
	SendCmd(p_dev, SYSEN);		  // - - 打开系统振荡器 0X01
	SendCmd(p_dev, LCDON);		  // - - 打开LCD偏压 LCDON
}

// 显示全部
void Diaplay_ShowAll(ht1621_t *p_dev)
{
	uint8_t i, j;
	for (i = 0; i < 100; i++)
	{
		Write_1621(p_dev, i, 0xFF);
	}
}

//清屏
void Clean_All(ht1621_t *p_dev)
{
	WriteAll_1621(p_dev, 0, Ht1621Tab, 16); //清除1621寄存器数据，暨清屏
}
