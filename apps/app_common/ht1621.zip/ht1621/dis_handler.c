#include "ft32f0xx.h"
#include "ft_gpio.h"
#include "util.h"
#include "stdbool.h"
#include "trace.h"
#include "systick.h"

#include "ht1621.h"
#include "seg_code.h"
#include "dis_handler.h"

#include "trace.h"

#define HT1621_CS GPIO_Pin_4
#define HT1621_WR GPIO_Pin_5
#define HT1621_RD GPIO_Pin_6
#define HT1621_DATA GPIO_Pin_7

static ht1621_t m_ht1621;

static uint32_t m_g_ch_left = 100;
static uint32_t m_g_ch_right = 160;
static uint32_t m_freg_left = 661;
static uint32_t m_freg_right = 677;

/**************************************************************************
*函数名：HT1621_GPIO_Config
*参  数：无
*返回值：无
*概  述：配置HT1621的IO口，并打开IO口外设时钟
**************************************************************************/
static void HT1621_GPIO_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	/* Enable GPIO clock */
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);

	//设置为推挽输出  DATA:PA7 CS:PA4
	GPIO_InitStructure.GPIO_Pin = HT1621_WR | HT1621_DATA | HT1621_CS;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}

static void HT1621_CS_HIGH(void)
{
	GPIO_SetBits(GPIOA, HT1621_CS);
}

static void HT1621_CS_LOW(void)
{
	GPIO_ResetBits(GPIOA, HT1621_CS);
}

static void HT1621_DATA_HIGH(void)
{
	GPIO_SetBits(GPIOA, HT1621_DATA);
}

static void HT1621_DATA_LOW(void)
{
	GPIO_ResetBits(GPIOA, HT1621_DATA);
}

static void HT1621_WR_HIGH(void)
{
	GPIO_SetBits(GPIOA, HT1621_WR);
}

static void HT1621_WR_LOW(void)
{
	GPIO_ResetBits(GPIOA, HT1621_WR);
}

void HT1621_Delay_ms(uint16_t ms)
{
	Delay_ms(ms);
}

void HT1621_Delay_us(uint16_t us)
{
	Delay_us(us);
}

void Display_Init(void)
{
	m_ht1621.gpio_config = HT1621_GPIO_Config;
	m_ht1621.CS_HIGH = HT1621_CS_HIGH;
	m_ht1621.CS_LOW = HT1621_CS_LOW;
	m_ht1621.DATA_HIGH = HT1621_DATA_HIGH;
	m_ht1621.DATA_LOW = HT1621_DATA_LOW;
	m_ht1621.WR_HIGH = HT1621_WR_HIGH;
	m_ht1621.WR_LOW = HT1621_WR_LOW;

	m_ht1621.delay_ms = HT1621_Delay_ms;
	m_ht1621.delay_us = HT1621_Delay_us;

	SysTick_Init();

	HT1621_Init(&m_ht1621);
	Clean_All(&m_ht1621);
	// Diaplay_ShowAll(&m_ht1621);

	Digital_Mode_0_Display(m_g_ch_left);
	Digital_Mode_1_Display(m_g_ch_right);

	// 661.700 Digita 7 8 9
	Digital_Mode_2_Set(Digital_7, 6, 0); //1:S3显示0 , 0:S3不显示
	Digital_Mode_2_Set(Digital_8, 6, 0); //11G
	Digital_Mode_2_Set(Digital_9, 1, 1); //11BE

	// Digita 10 11 S3 0---ABCDEF
	// Digital_Mode_2_Set(Digital_10, 7, 1); //11AFCD

	// //677.700 Digita 12 13 14
	// Digital_Mode_2_Set(Digital_12, 6, 1); //1:S4显示0 , 0:S4不显示
	// Digital_Mode_2_Set(Digital_13, 7, 0); //16G
	// Digital_Mode_2_Set(Digital_14, 7, 1); //16BE

	// Digita 15 16 S4 0---ABCDEF
	// Digital_Mode_2_Set(Digital_15, 7, 1); //16AFCD

	while (1)
	{
		Display_Serach(1000);
	}
}

void Digital_Mode_0_Display(uint32_t data)
{
	seg_data_t seg_data;
	SegData_Convertor(data, &seg_data);
	Digital_Mode_0_Set(Digital_1, seg_data.high, 1); //此处S2显示
	Digital_Mode_0_Set(Digital_2, seg_data.mid, 0);
	Digital_Mode_0_Set(Digital_3, seg_data.low, 0);
}

void Digital_Mode_0_Set(uint8_t digital, uint8_t data, uint8_t seg_x)
{
	encode_seg_code_t seg_code;
	uint8_t com_data_h, com_data_l;
	Digital_to_SegData(&seg_code, data);
	seg_code.seg_x = seg_x;
	SegData_to_SegCom_Mode_0(seg_code, &com_data_h, &com_data_l);

	switch (digital)
	{
	case Digital_1:
		Write_1621(&m_ht1621, DigitalSeg1_H, com_data_h);
		Write_1621(&m_ht1621, DigitalSeg1_L, com_data_l);
		break;

	case Digital_2:
		Write_1621(&m_ht1621, DigitalSeg2_H, com_data_h);
		Write_1621(&m_ht1621, DigitalSeg2_L, com_data_l);
		break;

	case Digital_3:
		Write_1621(&m_ht1621, DigitalSeg3_H, com_data_h);
		Write_1621(&m_ht1621, DigitalSeg3_L, com_data_l);
		break;

	default:
		break;
	}
}

void Digital_Mode_1_Display(uint32_t data)
{
	seg_data_t seg_data;
	SegData_Convertor(data, &seg_data);
	Digital_Mode_1_Set(Digital_4, seg_data.high, 1);
	Digital_Mode_1_Set(Digital_5, seg_data.mid, 0);
	Digital_Mode_1_Set(Digital_6, seg_data.low, 0);
}

void Digital_Mode_1_Set(uint8_t digital, uint8_t data, uint8_t seg_x)
{
	encode_seg_code_t seg_code;
	uint8_t com_data_h, com_data_l;
	Digital_to_SegData(&seg_code, data);
	seg_code.seg_x = seg_x;
	SegData_to_SegCom_Mode_1(seg_code, &com_data_h, &com_data_l);

	switch (digital)
	{
	case Digital_4:
		Write_1621(&m_ht1621, DigitalSeg4_H, com_data_h);
		Write_1621(&m_ht1621, DigitalSeg4_L, com_data_l);
		break;

	case Digital_5:
		Write_1621(&m_ht1621, DigitalSeg5_H, com_data_h);
		Write_1621(&m_ht1621, DigitalSeg5_L, com_data_l);
		break;

	case Digital_6:
		Write_1621(&m_ht1621, DigitalSeg6_H, com_data_h);
		Write_1621(&m_ht1621, DigitalSeg6_L, com_data_l);
		break;

	default:
		break;
	}
}

void Digital_Mode_2_Set(uint8_t digital, uint8_t data, uint8_t seg_x)
{
	encode_seg_code_t seg_code;
	uint8_t com_data_h, com_data_l;
	Digital_to_SegData(&seg_code, data);
	seg_code.seg_x = seg_x;
	SegData_to_SegCom_Mode_2(seg_code, &com_data_h, &com_data_l);

	switch (digital)
	{
	case Digital_7:
		Write_1621(&m_ht1621, DigitalSeg7_H, com_data_h);
		Write_1621(&m_ht1621, DigitalSeg7_L, com_data_l);
		break;

	case Digital_8:
		Write_1621(&m_ht1621, DigitalSeg8_H, com_data_h);
		Write_1621(&m_ht1621, DigitalSeg8_L, com_data_l);
		break;

	case Digital_9:
		Write_1621(&m_ht1621, DigitalSeg9_H, com_data_h);
		Write_1621(&m_ht1621, DigitalSeg9_L, com_data_l);
		break;

	case Digital_10:
		Write_1621(&m_ht1621, DigitalSeg10_H, com_data_h);
		Write_1621(&m_ht1621, DigitalSeg10_L, com_data_l);
		break;

	case Digital_12:
		Write_1621(&m_ht1621, DigitalSeg12_H, com_data_h);
		Write_1621(&m_ht1621, DigitalSeg12_L, com_data_l);
		break;

	case Digital_13:
		Write_1621(&m_ht1621, DigitalSeg13_H, com_data_h);
		Write_1621(&m_ht1621, DigitalSeg13_L, com_data_l);
		break;

	case Digital_14:
		Write_1621(&m_ht1621, DigitalSeg14_H, com_data_h);
		Write_1621(&m_ht1621, DigitalSeg14_L, com_data_l);
		break;
	case Digital_15:
		Write_1621(&m_ht1621, DigitalSeg15_H, com_data_h);
		Write_1621(&m_ht1621, DigitalSeg15_L, com_data_l);
		break;
	default:
		break;
	}
}

void Display_Serach_Clean(void)
{
	Write_1621(&m_ht1621, DigitalSeg12_L, 0x00);
	Write_1621(&m_ht1621, DigitalSeg13_L, 0x00);
	Write_1621(&m_ht1621, DigitalSeg14_L, 0x00);
	Write_1621(&m_ht1621, DigitalSeg15_L, 0x00);
}

void Display_Serach(uint32_t freq)
{
	Write_1621(&m_ht1621, DigitalSeg12_L, 0x08);
	Delay_ms(freq);
	Write_1621(&m_ht1621, DigitalSeg13_L, 0x08);
	Delay_ms(freq);
	Write_1621(&m_ht1621, DigitalSeg14_L, 0x08);
	Delay_ms(freq);
	Write_1621(&m_ht1621, DigitalSeg15_L, 0x08);
	Delay_ms(freq);
	Display_Serach_Clean();
	Delay_ms(freq);
}
