#ifndef _DIS_HANDLER_H_
#define _DIS_HANDLER_H_

void Display_Init(void);

#endif