/* Copyright (c) 2019 SENSORO Co.,Ltd. All Rights Reserved.
 *
 */

#include <stdint.h>
#include <stdbool.h>
#include "seg_code.h"

#include "trace.h"

static uint8_t m_seg_code[16] = {
    //---- 段显示   -gfe dcba
    0x3F, //[0]    [0011 1111]
    0x06, //[1]    [0000 0110]
    0x5B, //[2]    [0101 1011]
    0x4F, //[3]    [0100 1111]
    0x66, //[4]    [0110 0110]
    0x6D, //[5]    [0110 1101]
    0x7D, //[6]    [0111 1101]
    0x07, //[7]    [0000 0111]
    0x7F, //[8]    [0111 1111]
    0x67, //[9]    [0110 0111]
    0x77, //[A]    [0111 0111]
    0x7C, //[B]    [0111 1100]
    0x39, //[C]    [0011 1001]
    0x5E, //[D]    [0101 1110]
    0x79, //[E]    [0111 1001]
    0x71  //[F]    [0111 0001]
};

void Digital_to_SegData(encode_seg_code_t *seg_code, uint8_t Digital)
{

    uint8_t data = m_seg_code[Digital];

    seg_code->seg_a = data & BIT_0 ? 1 : 0;
    seg_code->seg_b = data & BIT_1 ? 1 : 0;
    seg_code->seg_c = data & BIT_2 ? 1 : 0;
    seg_code->seg_d = data & BIT_3 ? 1 : 0;
    seg_code->seg_e = data & BIT_4 ? 1 : 0;
    seg_code->seg_f = data & BIT_5 ? 1 : 0;
    seg_code->seg_g = data & BIT_6 ? 1 : 0;
    seg_code->seg_x = 0;
    trace_info("data =0x%02x\r\n", data);
    trace_info("seg_code->xgfedcba=%d%d%d%d %d%d%d%d\r\n",
               seg_code->seg_x,
               seg_code->seg_g,
               seg_code->seg_f,
               seg_code->seg_e,
               seg_code->seg_d,
               seg_code->seg_c,
               seg_code->seg_b,
               seg_code->seg_a);
}
//仅适用于数码管1.2.3
void SegData_to_SegCom_Mode_0(encode_seg_code_t seg_code, uint8_t *com_data_h, uint8_t *com_data_l)
{

    seg_com_t seg_high, seg_low;
    /*  数码管1     数码管2
	    COM1: X1   3D
	    COM2: 3C   3E
	    COM3: 3G   3F
	    COM4: 3B   3A
	*/
    //比如 0x06, //[1]    [0000 0110]
    seg_high.com1 = seg_code.seg_d;
    seg_high.com2 = seg_code.seg_e;
    seg_high.com3 = seg_code.seg_f;
    seg_high.com4 = seg_code.seg_a;

    seg_low.com1 = seg_code.seg_x;
    seg_low.com2 = seg_code.seg_c;
    seg_low.com3 = seg_code.seg_g;
    seg_low.com4 = seg_code.seg_b;

    *com_data_h = ((seg_high.com1 << 0) & BIT_0) |
                  ((seg_high.com2 << 1) & BIT_1) |
                  ((seg_high.com3 << 2) & BIT_2) |
                  ((seg_high.com4 << 3) & BIT_3);

    *com_data_l = (seg_low.com1 << 0) & BIT_0 |
                  (seg_low.com2 << 1) & BIT_1 |
                  (seg_low.com3 << 2) & BIT_2 |
                  (seg_low.com4 << 3) & BIT_3;

    trace_info("seg_high.com1com2com3com4 %d%d%d%d\r\n", seg_high.com1, seg_high.com2, seg_high.com3, seg_high.com4);
    trace_info("seg_low.com1com2com3com4 %d%d%d%d\r\n", seg_low.com1, seg_low.com2, seg_low.com3, seg_low.com4);

    trace_info("com_data_h =0x%02x\r\n", *com_data_h);
    trace_info("com_data_l =0x%02x\r\n", *com_data_l);
}

//仅适用于数码管4.5.6
void SegData_to_SegCom_Mode_1(encode_seg_code_t seg_code, uint8_t *com_data_h, uint8_t *com_data_l)
{

    seg_com_t seg_high, seg_low;
    /*  数码管32     数码管31
	    COM1: 4A   S1
	    COM2: 4F   4B
	    COM3: 4E   4G
	    COM4: 4D   4C
	*/
    //比如 0x06, //[1]    [0000 0110]
    seg_low.com1 = seg_code.seg_x;
    seg_low.com2 = seg_code.seg_b;
    seg_low.com3 = seg_code.seg_g;
    seg_low.com4 = seg_code.seg_c;

    seg_high.com1 = seg_code.seg_a;
    seg_high.com2 = seg_code.seg_f;
    seg_high.com3 = seg_code.seg_e;
    seg_high.com4 = seg_code.seg_d;

    *com_data_h = ((seg_high.com1 << 0) & BIT_0) |
                  ((seg_high.com2 << 1) & BIT_1) |
                  ((seg_high.com3 << 2) & BIT_2) |
                  ((seg_high.com4 << 3) & BIT_3);

    *com_data_l = (seg_low.com1 << 0) & BIT_0 |
                  (seg_low.com2 << 1) & BIT_1 |
                  (seg_low.com3 << 2) & BIT_2 |
                  (seg_low.com4 << 3) & BIT_3;

    trace_info("seg_high.com1com2com3com4 %d%d%d%d\r\n", seg_high.com1, seg_high.com2, seg_high.com3, seg_high.com4);
    trace_info("seg_low.com1com2com3com4 %d%d%d%d\r\n", seg_low.com1, seg_low.com2, seg_low.com3, seg_low.com4);

    trace_info("com_data_h =0x%02x\r\n", *com_data_h);
    trace_info("com_data_l =0x%02x\r\n", *com_data_l);
}

//仅适用于数码管7.8.9.10.11.12.13.14.15
void SegData_to_SegCom_Mode_2(encode_seg_code_t seg_code, uint8_t *com_data_h, uint8_t *com_data_l)
{

    seg_com_t seg_high, seg_low;
    /*  数码管9     数码管10
	    COM1: 7A   S3
	    COM2: 7F   7B
	    COM3: 7E   7G
	    COM4: 7D   7C
	*/
    //比如 0x06, //[1]    [0000 0110]
    seg_high.com1 = seg_code.seg_x;
    seg_high.com2 = seg_code.seg_b;
    seg_high.com3 = seg_code.seg_g;
    seg_high.com4 = seg_code.seg_c;

    seg_low.com1 = seg_code.seg_a;
    seg_low.com2 = seg_code.seg_f;
    seg_low.com3 = seg_code.seg_e;
    seg_low.com4 = seg_code.seg_d;

    *com_data_h = ((seg_high.com1 << 0) & BIT_0) |
                  ((seg_high.com2 << 1) & BIT_1) |
                  ((seg_high.com3 << 2) & BIT_2) |
                  ((seg_high.com4 << 3) & BIT_3);

    *com_data_l = (seg_low.com1 << 0) & BIT_0 |
                  (seg_low.com2 << 1) & BIT_1 |
                  (seg_low.com3 << 2) & BIT_2 |
                  (seg_low.com4 << 3) & BIT_3;

    trace_info("seg_high.com1com2com3com4 %d%d%d%d\r\n", seg_high.com1, seg_high.com2, seg_high.com3, seg_high.com4);
    trace_info("seg_low.com1com2com3com4 %d%d%d%d\r\n", seg_low.com1, seg_low.com2, seg_low.com3, seg_low.com4);

    trace_info("com_data_h =0x%02x\r\n", *com_data_h);
    trace_info("com_data_l =0x%02x\r\n", *com_data_l);
}
